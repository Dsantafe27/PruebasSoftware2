package edu.compensar.ps2.model;

public enum TipoTransaccion {
    INGRESO, GASTO
}

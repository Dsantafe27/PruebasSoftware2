# Finanzas Console (Java 11)

Aplicación de consola para registrar ingresos/egresos, gestionar categorías y generar reportes.

## Requisitos
- JDK 11 o superior (si usas JDK 11 asegúrate de compilar con `--release 11` o usa este `pom.xml`)
- Maven 3.6+

## Ejecutar
```bash
mvn -q -f pom.xml compile
mvn -q -f pom.xml exec:java
```

Si prefieres ejecutar con `java` directamente:
```bash
javac -d out $(git ls-files '*.java')   # o lista manual de archivos
java -cp out edu.compensar.ps2.app.FinanzasApp
```
